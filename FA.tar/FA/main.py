from apiclasses import *
from fastapi import FastAPI
import os



app = FastAPI(openapi_url=None)
#app = FastAPI()
 


#
#from requestshandler import *
from static import *
from tokensManager import *
from studentsManager import *
from loginManager import *
#

### TOKEN FUNCTIONS
@app.post(f"/{FUNCTIONS['genToken']}")
async def gxc():
    return genToken()

@app.post(f"/{FUNCTIONS['revokeTokens']}")
async def rxc():
    return revokeTokens()
###

### LOGIN FUNCTIONS
@app.post(f"/{FUNCTIONS['signUp']}")
async def suxz(TOKEN: TOKEN, LOGIN: LOGIN):
    if(validToken(TOKEN)):
        return addLoginCreds(LOGIN)
    else:
        return ERROR_CODES['unauthorizedTOKENS']

@app.post(f"/{FUNCTIONS['signIn']}")
async def sixz(TOKEN: TOKEN, LOGIN: LOGIN):
    if(validToken(TOKEN)):
        return getLoginType(LOGIN)
    else:
        return ERROR_CODES['unauthorizedTOKENS']

"""
@app.post(f"/{FUNCTIONS['signUp']}")
async def suxz(TOKEN: TOKEN, LOGIN: LOGIN):
    if(validToken(TOKEN)):
        return addLoginCreds(LOGIN)
    else:
        return ERROR_CODES['unauthorizedTOKENS']
"""

###

### STUDENT FUNCTIONS
@app.post(f"/{FUNCTIONS['addStudent']}")
async def saxz(TOKEN: TOKEN, STUDENT: STUDENT):
    if(validToken(TOKEN)):
        return addStudent(STUDENT)
    else:
        return ERROR_CODES['unauthorizedTOKENS']

@app.post(f"/{FUNCTIONS['getStudent']}")
async def sgxz(TOKEN: TOKEN):
    if(validToken(TOKEN)):
        return getAllStudents()
    else:
        return ERROR_CODES['unauthorizedTOKENS']

@app.post(f"/{FUNCTIONS['delStudent']}")
async def sdxz(TOKEN: TOKEN,STUDENT:STUDENT):
    if(validToken(TOKEN)):
        return deleteStudent(STUDENT)
    else:
        return ERROR_CODES['unauthorizedTOKENS']
        
@app.post(f"/{FUNCTIONS['modStudent']}")
async def smxz(TOKEN: TOKEN,STUDENT:STUDENT,NEWSTUDENT:STUDENT):
    if(validToken(TOKEN)):
        return modifyStudent(STUDENT,NEWSTUDENT)
    else:
        return ERROR_CODES['unauthorizedTOKENS']
### 

### INSTRUCTORS FUNCTIONS

###
