#!/bin/bash

#nohup python -m http.server 80 &
uvicorn main:app \
--reload \
--host 0.0.0.0 \
--port 443 \
--ssl-keyfile=./key.pem \
--ssl-certfile=./cert.pem 
