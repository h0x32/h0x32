from tinydb import *
from tinydb.operations import delete
import datetime

from static import *
from apiclasses import STUDENT

selfStudents = TinyDB(DB_CLASSES['SELF_STUDENTS_CLASS'])
allStudents = TinyDB(DB_CLASSES['ALL_STUDENTS_CLASS'])


def addStudent(student: STUDENT):
    return {"DOCUMENT_ID": allStudents.insert(student.toDictJSON())}


def getAllStudents():
    return allStudents.table('_default').all()


def searchStudent(student: STUDENT):
    return allStudents.search(where('NICKNAME') == student.NICKNAME)


def modifyStudent(student: STUDENT, newStudent: STUDENT):
    docs = searchStudent(student)
    for doc in docs:
        print(
            f'Modifying DATA:[{doc}] ID:[{doc.doc_id}] with DATA:[{newStudent.toDictJSON()}]')
        allStudents.update(newStudent.toDictJSON(), doc_ids=[doc.doc_id])


def deleteStudent(student: STUDENT):
    docs = searchStudent(student)
    i = 0
    for doc in docs:
        print(f'Removing DATA:[{doc}] ID:[{doc.doc_id}]')
        allStudents.remove(doc_ids=[doc.doc_id])
        i += 1
    return {"DOCUMENTS": i}
