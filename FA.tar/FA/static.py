# DATABASE CLASS FILENAMES
DB_CLASSES = {
    "ALL_USERS_CLASS":          "ALL_USERS",
    "ALL_STUDENTS_CLASS":       "ALL_STUDENTS",
    "ALL_INSTRUCTORS_CLASS":    "ALL_INSTRUCTORS",
    "ALL_PACKAGES_CLASS":       "ALL_PACKAGES",
    "ALL_LESSONS_CLASS":        "ALL_LESSONS",
    "SELF_LESSONS_CLASS":       "SELF_LESSONS",
    "SELF_STUDENTS_CLASS":      "SELF_STUDENTS",
    "TOKENS_CLASS":             "TOKENS",
}

# API URL FUNCTIONS
FUNCTIONS = {
    "addStudent":       "saxz",
    "getStudent":       "sgxz",
    "delStudent":       "sdxz",
    "modStudent":       "smxz",

    "addInstructor":    "aixz",
    "delInstructor":    "dixz",
    "getInstructor":    "gixz",

    "signUp":           "suxz",
    "signIn":           "sixz",
    "signIN-Details":   "dsxz",

    "genToken":         "gxc",
    "revokeTokens":     "rxc"
}

# API REPLY CODES
REPLY_CODES = {
    'OK': 'D0N3'
}

# API ERROR CODES
ERROR_CODES = {
    "studentAdditionFailure":   "FS03",
    "unauthorizedTOKENS":       "K00X",
    "unaviableUser":            "U00X"
}
