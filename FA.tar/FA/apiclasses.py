from typing import Optional
from pydantic import BaseModel, constr
import datetime
import json

class LOGIN(BaseModel):
    EMAIL: constr(min_length=3)
    USERNAME: str
    PASSWD: str
    TYPE: Optional[int]

    def toDictJSON(self): 
        return json.loads(self.json())

class TOKEN(BaseModel):
    PUBLIC_KEY: str
    PRIVATE_KEY: Optional[str]
    N: Optional[int]
    P: Optional[int]
    E: Optional[int]
    Q: Optional[int]
    U: Optional[int]
    D: Optional[int]
    ISSUED: Optional[datetime.datetime]

    def toDictJSON(self): 
        return json.loads(self.json())

class STUDENT(BaseModel):
    ID: Optional[str]
    NICKNAME: Optional[str]
    CBR_NUMBER: Optional[int]
    COMPOSITE_NAME: Optional[str]
    GENDER: Optional[constr(max_length=1,regex='[M|V|m|v]')]
    STREET: Optional[str]
    HOUSE_NUMBER: Optional[int]
    POSTAL_CODE: Optional[str]
    RESIDENCE: Optional[str]
    ACTIVE_STATUS: Optional[bool]
    PACKAGE: Optional[str]

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.ID = self.NICKNAME[0:4]

    def toDictJSON(self): 
        return json.loads(self.json())

class INSTRUCTOR(BaseModel):
    ID: Optional[str]
    NICKNAME: Optional[str]
    CBR_NUMBER: Optional[int]
    COMPOSITE_NAME: Optional[str]
    GENDER: Optional[constr(max_length=1,regex='[M|V|m|v]')]
    STREET: Optional[str]
    HOUSE_NUMBER: Optional[int]
    POSTAL_CODE: Optional[str]
    RESIDENCE: Optional[str]
    ACTIVE_STATUS: Optional[bool]
    PACKAGE: Optional[str]

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.ID = self.NICKNAME[0:4]

    def toDictJSON(self): 
        return json.loads(self.json())