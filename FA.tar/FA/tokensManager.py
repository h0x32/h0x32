from tinydb import *
from tinydb.operations import delete
from Crypto.PublicKey import RSA
import datetime

from static import *
from apiclasses import TOKEN

db = TinyDB(DB_CLASSES['TOKENS_CLASS'])


def genToken(token: TOKEN):
    db.insert(token.toDictJSON())


def genToken():
    keyPair = RSA.generate(1024)

    pubKey = keyPair.publickey()

    pubKeyPEM = pubKey.exportKey().decode(
        'ascii').split('-----')[2].replace('\n', '')

    privKeyPEM = keyPair.exportKey().decode(
        'ascii').split('-----')[2].replace('\n', '')

    JTOKEN = TOKEN(**{
        "PUBLIC_KEY": pubKeyPEM,
        "PRIVATE_KEY": privKeyPEM,
        "N": keyPair.n,
        "P": keyPair.p,
        "E": keyPair.e,
        "Q": keyPair.q,
        "U": keyPair.u,
        "D": keyPair.d,
        "ISSUED": str(datetime.datetime.now())
    })

    db.insert(JTOKEN.toDictJSON())
    return JTOKEN


def revokeTokens():
    all = db.all()
    i = 0
    for doc in all:
        db.remove(doc_ids=[doc.doc_id])
        i += 1
    return {"TOKENS": i}


def validToken(token: TOKEN):
    print(token.PUBLIC_KEY)
    docs = db.search(where('PUBLIC_KEY') == token.PUBLIC_KEY)
    return True if len(docs) > 0 else False
