from tinydb import *
from tinydb.operations import delete
import datetime

from static import *
from apiclasses import LOGIN

db = TinyDB(DB_CLASSES['ALL_USERS_CLASS'])


def addLoginCreds(login: LOGIN):
    return {"DOCUMENT_ID": db.insert(login.toDictJSON())}


def getAllLogins():
    return db.table('_default').all()


def searchLogins(login: LOGIN):
    return db.search(where('USERNAME') == login.USERNAME)


def getLoginType(login: LOGIN):
    logins = db.search(where('USERNAME') ==
                       login.USERNAME and where('PASSWD') == login.PASSWD)
    return {"TYPE": None if len(logins) == 0 else LOGIN(**logins[0]).TYPE}


def deleteLogin(login: LOGIN):
    docs = searchLogins(login)
    i = 0
    for doc in docs:
        print(f'Removing DATA:[{doc}] ID:[{doc.doc_id}]')
        allStudents.remove(doc_ids=[doc.doc_id])
        i += 1
    return {"DOCUMENTS": i}
