#!/bin/bash

sudo dnf -y install dnf-plugins-core 
sudo dnf -y config-manager --add-repo https://download.docker.com/linux/fedora/docker-ce.repo 
sudo dnf install -y docker-ce docker-ce-cli containerd.io 
sudo dnf install -y xauth
sudo systemctl start docker 
xhost local:root
sudo groupadd docker
sudo gpasswd -a $USER docker
sudo setfacl -m user:$USER:rw /var/run/docker.sock

docker stop -t 0 bankplus 
docker rm bankplus 


docker run -dit --name="bankplus" --net=host -v "$HOME/Downloads:/root/Downloads:rw" --env="DISPLAY" -v "/tmp/.X11-unix:/tmp/.X11-unix:rw" -v "$HOME/.Xauthority:/root/.Xauthority:rw" --privileged ftso/docker-oracle-java6-firefox

docker exec -i bankplus apt-get update -y 
docker exec -i bankplus apt-get install -y wget 
docker exec -i bankplus apt-get install -y vnc4server 
docker exec -i bankplus wget https://github.com/h0x32/h0x32/raw/main/ar.ttf -P /usr/share/fonts/arr
docker exec -i bankplus apt-get install -y xpad 
docker exec -i bankplus apt-get install -y gnome-calculator
#docker exec -i bankplus bash -c "echo 'pref("browser.startup.page", 3);' >> /root/.*mozill*/fire*/*def*/prefs.js"


sudo mkdir /tamweely
sudo mv *.png /tamweely/
sudo mv *.desktop /usr/share/applications/
