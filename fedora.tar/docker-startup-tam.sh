sudo systemctl start docker
